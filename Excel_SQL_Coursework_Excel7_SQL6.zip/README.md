# Excel & SQL Coursework

## Excel
day1.xlsx - SUM, AVERAGE, MAX, MIN, COUNT, COUNTA, COUNTBLANK
day2.xlsx - IF, IFS, COUNTIF, COUNTIFS, SUMIF, SUMIFS, AVERAGEIF, AVERAGEIFS
day3.xlsx - Conditional Formatting, Filter, Sort
day4.xlsx - Pivot Table analysis
day5.xlsx - Sales Dashboard
day6.xlsx - Pivot analysis
day7.xlsx - Spotify Dataset + Dashboard

## SQL
day1.sql - Database and table creation + SELECT + WHERE
day2.sql - E-commerce tables + constraints
day3.sql - WHERE operators
day4.sql - COUNT, SUM, AVG, MAX, MIN
day5.sql - GROUP BY + ORDER BY
day6.sql - JOIN + combined queries
