-- DAY 1: Database + Tables + SELECT + WHERE
CREATE DATABASE IF NOT EXISTS student_db;
USE student_db;
CREATE TABLE student(student_id INT PRIMARY KEY,name VARCHAR(50) NOT NULL,age INT,course VARCHAR(30),gender VARCHAR(10));
CREATE TABLE academic(academic_id INT PRIMARY KEY,student_id INT,subject VARCHAR(50),marks INT,FOREIGN KEY(student_id) REFERENCES student(student_id));
CREATE TABLE fees(fee_id INT PRIMARY KEY,student_id INT,total_fee DECIMAL(10,2),paid_fee DECIMAL(10,2),due_fee DECIMAL(10,2),FOREIGN KEY(student_id) REFERENCES student(student_id));
CREATE TABLE library(library_id INT PRIMARY KEY,student_id INT,book_name VARCHAR(100),issue_date DATE,return_date DATE,FOREIGN KEY(student_id) REFERENCES student(student_id));
INSERT INTO student VALUES(1,'Rahul',22,'MCA','Male'),(2,'Priya',23,'MCA','Female'),(3,'Amit',21,'BCA','Male'),(4,'Neha',22,'MCA','Female');
SELECT * FROM student;
SELECT * FROM academic;
SELECT * FROM fees;
SELECT * FROM library;
SELECT * FROM student WHERE age>=22;
SELECT name,age FROM student WHERE course='MCA';
