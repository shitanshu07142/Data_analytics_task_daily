-- DAY 2: E-commerce tables + constraints
CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;
CREATE TABLE customer(customer_id INT PRIMARY KEY,customer_name VARCHAR(50) NOT NULL,email VARCHAR(100) UNIQUE,city VARCHAR(50));
CREATE TABLE product(product_id INT PRIMARY KEY,product_name VARCHAR(100) NOT NULL,category VARCHAR(50),price DECIMAL(10,2) CHECK(price>0),stock INT DEFAULT 0);
CREATE TABLE orders(order_id INT PRIMARY KEY,customer_id INT,product_id INT,quantity INT CHECK(quantity>0),order_date DATE,FOREIGN KEY(customer_id) REFERENCES customer(customer_id),FOREIGN KEY(product_id) REFERENCES product(product_id));
CREATE TABLE shipment(shipment_id INT PRIMARY KEY,order_id INT,shipment_date DATE,status VARCHAR(30) DEFAULT 'Processing',FOREIGN KEY(order_id) REFERENCES orders(order_id));
CREATE TABLE return_table(return_id INT PRIMARY KEY,order_id INT,reason_for_return VARCHAR(100),return_date DATE,FOREIGN KEY(order_id) REFERENCES orders(order_id));
