-- DAY 3: WHERE operators
USE ecommerce_db;
SELECT * FROM product WHERE price>1000;
SELECT * FROM product WHERE price<50000;
SELECT * FROM product WHERE price>=1000 AND stock>10;
SELECT * FROM product WHERE category='Electronics' OR price<1000;
SELECT * FROM product WHERE price BETWEEN 1000 AND 20000;
SELECT * FROM product WHERE category IN ('Electronics','Accessories');
SELECT * FROM product WHERE product_name LIKE 'M%';
SELECT * FROM product WHERE price<>1000;
