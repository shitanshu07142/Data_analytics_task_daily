-- DAY 4: Aggregate functions
USE ecommerce_db;
SELECT COUNT(*) AS total_products FROM product;
SELECT SUM(stock) AS total_stock FROM product;
SELECT AVG(price) AS average_price FROM product;
SELECT MAX(price) AS highest_price FROM product;
SELECT MIN(price) AS lowest_price FROM product;
