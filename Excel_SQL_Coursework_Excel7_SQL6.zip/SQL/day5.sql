-- DAY 5: GROUP BY + ORDER BY
USE ecommerce_db;
SELECT category,COUNT(*) AS product_count FROM product GROUP BY category;
SELECT category,SUM(stock) AS total_stock FROM product GROUP BY category;
SELECT * FROM product ORDER BY price DESC;
SELECT * FROM product ORDER BY product_name ASC;
