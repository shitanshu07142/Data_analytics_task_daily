-- DAY 6: Combined practice + JOIN
USE ecommerce_db;
SELECT p.product_name,p.price,o.quantity
FROM product p JOIN orders o ON p.product_id=o.product_id;
SELECT c.customer_name,o.order_id,p.product_name
FROM customer c JOIN orders o ON c.customer_id=o.customer_id
JOIN product p ON o.product_id=p.product_id;
SELECT reason_for_return,COUNT(*) AS return_count
FROM return_table GROUP BY reason_for_return;
